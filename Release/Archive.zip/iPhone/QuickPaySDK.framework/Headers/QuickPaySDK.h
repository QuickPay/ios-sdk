//
//  QuickPaySDK.h
//  QuickPaySDK
//
//  Created by Steffen Lund Andersen on 06/11/2018.
//  Copyright © 2018 QuickPay. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for QuickPaySDK.
FOUNDATION_EXPORT double QuickPaySDKVersionNumber;

//! Project version string for QuickPaySDK.
FOUNDATION_EXPORT const unsigned char QuickPaySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like
// #import <QuickPaySDK/PublicHeader.h>
